
// Ce fichier a été supprimé à la demande de l'utilisateur.
export const DetailedDailyTable = () => null;
