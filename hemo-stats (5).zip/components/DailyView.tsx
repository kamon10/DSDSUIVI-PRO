// Ce fichier est obsolète, les fonctionnalités ont été fusionnées dans VisualDashboard.tsx (onglet Cockpit).
export const DailyView = () => null;